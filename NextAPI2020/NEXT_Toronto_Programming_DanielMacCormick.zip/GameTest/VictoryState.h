#pragma once

enum class VictoryState
{
	StillPlaying,
	Victory,
	Loss
};