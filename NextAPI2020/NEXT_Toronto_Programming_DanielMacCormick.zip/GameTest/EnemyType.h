#pragma once


enum class EnemyType
{
	Basic,

	Fast,
	Strong,

	Healer,
	Speeder,
	Shooter,
	EMP,
	Bomber,

	Boss,

	Count
};
