#pragma once

enum class ProjectileShootEffect
{
	Basic,
	TriShot,

	Count
};

enum class ProjectileFlightEffect
{
	Basic,
	Homing,

	Count
};

enum class ProjectileDestroyEffect
{
	Basic,
	Splash,

	Count
};
